﻿// C# example program to demonstrate OpenTK
//
// Steps:
using System;
using System.Collections.Generic;
using OpenTK;
using System.Drawing;
using OpenTK.Graphics;
using OpenTK.Input;
using OpenTK.Graphics.OpenGL;

namespace RubiksCube
{
    class Game : GameWindow
    {
        private readonly IPart cube;
        private bool canRotate;
        public Game() : base(800, 600, GraphicsMode.Default, "OpenTK Quick Start Sample")
        {
            VSync = VSyncMode.On;
            cube = new Cube(25,25, 25);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            GL.ClearColor(0.1f, 0.2f, 0.5f, 0.0f);
            GL.Enable(EnableCap.DepthTest);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            GL.Viewport(ClientRectangle.X, ClientRectangle.Y, ClientRectangle.Width, ClientRectangle.Height);
            Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView((float)Math.PI / 4, Width / (float)Height, 1.0f, 64.0f);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref projection);
        }

        protected override void OnMouseMove(MouseMoveEventArgs e)
        {
            if (canRotate)
                cube.Rotate(e.YDelta / 50.0, e.XDelta / 50.0, 0);
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            canRotate = true;
        }

        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            canRotate = false;
        }

        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            Matrix4 modelview = Matrix4.LookAt(new Vector3(-5, 0, 0), Vector3.UnitZ, Vector3.UnitY);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref modelview);

            cube.Draw(Draw);

            SwapBuffers();
        }

        private void Draw(Color color, IEnumerable<Vector> vertexes, BeginMode mode)
        {
            GL.Begin(mode);
            GL.Color3(color);
            foreach(var v in vertexes)
                GL.Vertex3(v.ToVector3d());
            GL.End();
        }


        [STAThread]
        static void Main()
        {
            using (Game game = new Game())
            {
                game.Run(30.0);
            }
        }
    }
}