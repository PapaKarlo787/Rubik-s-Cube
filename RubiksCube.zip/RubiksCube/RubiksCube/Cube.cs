﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using OpenTK.Graphics.OpenGL;

namespace RubiksCube
{
    class Cube : IPart
    {
        private List<CubePart> parts = new List<CubePart>();

        public Cube(int x, int y, int z)
        {
            var size = 1.0 / Math.Max(x, Math.Max(y, z));
            for (var i = 0; i < x; i++)
                for (var l = 0; l < y; l++)
                    for (var k = 0; k < z; k++)
                    {
                        var isBorder = i % (x - 1) == 0 || l % (y - 1) == 0 || k % (z - 1) == 0;
                        parts.Add(isBorder ? new CubePart(new Vector(i, l, k), size) : null);
                    }
        }

        public void Rotate(double ux, double uy, double uz)
        {
            parts.Where(p => p != null).ToList().ForEach(p => p.Rotate(ux, uy, uz));
        }

        public void Draw(Action<Color, IEnumerable<Vector>, BeginMode> drawer)
        {
            parts.Where(p => p != null).ToList().ForEach(p => p.Draw(drawer));
        }
    }
}
