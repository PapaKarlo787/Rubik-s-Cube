﻿using OpenTK.Graphics.OpenGL;
using System.Drawing;
using System;

namespace RubiksCube
{
    class PyramidePart : Part
    {
        public PyramidePart(Vector center, double size) : base(center, BeginMode.Triangles)
        {
            vertexes = new[] {new Vector(0, 1, 0), new Vector(0, -1, -Math.Sqrt(3)) * 0.5,
                new Vector(Math.Sqrt(3), 1, 1) * 0.5, new Vector(-Math.Sqrt(3), 1, 1) * 0.5};
            edges = new[] { new[] { 0, 1, 2 }, new[] { 0, 1, 3 }, new[] { 0, 2, 3 }, new[] { 1, 2, 3 } };
            colors = new[] { Color.Red, Color.Yellow, Color.Blue, Color.Green };
            for (var i = 0; i < vertexes.Length; i++)
                vertexes[i] *= size;
        }
    }
}
