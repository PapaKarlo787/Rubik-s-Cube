﻿using OpenTK.Graphics.OpenGL;
using System.Drawing;
using System;

namespace RubiksCube
{
    class PyramidePart : Part
    {
        public PyramidePart(Vector center, double size) : base(center, BeginMode.Triangles)
        {
            var pi3 = Math.PI / 1.5;
            var v = new Vector(0, 1, 0);
            vertexes = new[] { v, v.Rotate(pi3, 0, 0, true), v.Rotate(pi3, pi3, 0, true), v.Rotate(pi3, -pi3, 0, true) };
            edges = new[] { new[] { 0, 1, 2 }, new[] { 0, 1, 3 }, new[] { 0, 2, 3 }, new[] { 1, 2, 3 } };
            colors = new[] { Color.Red, Color.Yellow, Color.Blue, Color.Green };
            for (var i = 0; i < vertexes.Length; i++)
                vertexes[i] *= size*0.5;
        }
    }
}
