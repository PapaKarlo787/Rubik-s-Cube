﻿using System.Collections.Generic;
using OpenTK.Graphics.OpenGL;
using System.Drawing;
using System;

namespace RubiksCube
{
    interface IPart
    {
        void Rotate(double ux, double uy, double uz);
        void Draw(Action<Color, IEnumerable<Vector>, BeginMode> drawer);
    }
}
