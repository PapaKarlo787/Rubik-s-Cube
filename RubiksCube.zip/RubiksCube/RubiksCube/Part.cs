﻿using System;
using System.Collections.Generic;
using System.Drawing;
using OpenTK.Graphics.OpenGL;
using System.Threading.Tasks;

namespace RubiksCube
{
    abstract class Part : IPart
    {
        protected Color[] colors;
        protected int[][] edges;
        protected Vector[] vertexes;
        protected Vector center;
        protected BeginMode mode;

        public Part(Vector center, BeginMode mode)
        {
            this.center = center;
            this.mode = mode;
        }

        public void Rotate(double ux, double uy, double uz)
        {
            center.Rotate(ux, uy, uz);
            foreach (var v in vertexes)
                v.Rotate(ux, uy, uz);
        }

        public void Draw(Action<Color, IEnumerable<Vector>, BeginMode> drawer)
        {
            for (var i = 0; i < edges.Length; i++)
            {
                var vertexes = new List<Vector>();
                foreach (var e in edges[i])
                    vertexes.Add(this.vertexes[e]+center);
                drawer(colors[i], vertexes, mode);
            }
        }
    }
}
