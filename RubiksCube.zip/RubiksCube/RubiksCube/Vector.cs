﻿using System;
using OpenTK;

namespace RubiksCube
{
    class Vector
    {
        private double x, y, z;
        public double X { get => x; }
        public double Y { get => y; }
        public double Z { get => z; }

        public Vector(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public void Rotate(double ux, double uy, double uz)
        {
            Rotate(ux, ref y, ref z);
            Rotate(uy, ref z, ref x);
            Rotate(uz, ref x, ref y);
        }

        private void Rotate(double ungle, ref double coord1, ref double coord2)
        {
            var temp = coord1 * Math.Cos(ungle) - coord2 * Math.Sin(ungle);
            coord2 = coord1 * Math.Sin(ungle) + coord2 * Math.Cos(ungle);
            coord1 = temp;
        }

        public static Vector operator +(Vector v1, Vector v2) => new Vector(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);

        public static Vector operator *(Vector v, double s) => new Vector(v.x * s, v.y * s, v.z * s);

        public Vector3d ToVector3d() => new Vector3d(x, y, z);
    }
}
